package br.com.fabioclaret.etimrelativelayout

import android.app.Activity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.com.fabioclaret.etimrelativelayout.databinding.ActivityFaturasBinding
import com.vinaygaba.creditcardview.CardType
import com.vinaygaba.creditcardview.CreditCardView
import com.vinaygaba.creditcardview.CreditCardView.CreditCardType

class Faturas : AppCompatActivity() {
    private lateinit var binding: ActivityFaturasBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_faturas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val cartao: CreditCardView = binding.cartao
        cartao.setCardNumber("234 5432 8790 3759");
        cartao.setCardName("Beatriz O M Piacente");
        cartao.setExpiryDate("03/2030");
        cartao.setType(CardType.MASTERCARD);
    }
}